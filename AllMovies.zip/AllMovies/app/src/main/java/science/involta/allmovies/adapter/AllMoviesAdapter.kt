package science.involta.allmovies.adapter

import android.annotation.SuppressLint
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import science.involta.allmovies.R
import science.involta.allmovies.data.local.database.AllMoviesListEntity
import science.involta.allmovies.databinding.ItemAllMoviesBinding
import science.involta.allmovies.utils.Constants.RELEASE_TEXT

//Адаптер для ресайклер вью всех 3- фрагментов

class AllMoviesAdapter(private val onItemClickListener: ItemClickListener)
    : RecyclerView.Adapter<AllMoviesAdapter.AllMoviesViewHolder>() {

    private lateinit var binding: ItemAllMoviesBinding
    //Список для дата класса MoviesListEntity, для оторажения данных в ресайклер вью

    private val allMoviesListEntity: MutableList<AllMoviesListEntity> = mutableListOf()

    override fun onCreateViewHolder( parent: ViewGroup, viewType: Int ): AllMoviesViewHolder {
        binding = ItemAllMoviesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AllMoviesViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AllMoviesViewHolder, position: Int) {
        holder.bind(allMoviesListEntity[position], onItemClickListener)

    }
    override fun getItemCount(): Int = allMoviesListEntity.size

    //Обновляет данные в ресайклер вью, notifyDataSetChanged() - без этой функции в этом отображении настройки ресайклера не работает
    @SuppressLint("NotifyDataSetChanged")
    fun updateList(listMovies: List<AllMoviesListEntity>){
        allMoviesListEntity.clear()
        allMoviesListEntity.addAll(listMovies)
        notifyDataSetChanged()
    }

    class AllMoviesViewHolder(private val viewBinding: ItemAllMoviesBinding): RecyclerView.ViewHolder(viewBinding.root){



        @SuppressLint("SetTextI18n")
        fun bind(moviesListEntity: AllMoviesListEntity, onItemCallback: ItemClickListener) = with(viewBinding){

            var cnt = 0.0
            tViewTitle.text = moviesListEntity.title
            tViewRelease.text = "$RELEASE_TEXT ${moviesListEntity.releaseDate}"
            tViewRating.text = moviesListEntity.voteAverage.toString()

            ratingImage1.setImageResource( starRate(moviesListEntity.voteAverage ?: 0.0, cnt) )
            cnt++
            ratingImage2.setImageResource( starRate(moviesListEntity.voteAverage ?: 0.0, cnt) )
            cnt++
            ratingImage3.setImageResource( starRate(moviesListEntity.voteAverage ?: 0.0, cnt) )
            cnt++
            ratingImage4.setImageResource( starRate(moviesListEntity.voteAverage ?: 0.0, cnt) )
            cnt++
            ratingImage5.setImageResource( starRate(moviesListEntity.voteAverage ?: 0.0, cnt) )
            cnt++
            ratingImage6.setImageResource( starRate(moviesListEntity.voteAverage ?: 0.0, cnt) )
            cnt++
            ratingImage7.setImageResource( starRate(moviesListEntity.voteAverage ?: 0.0, cnt) )
            cnt++
            ratingImage8.setImageResource( starRate(moviesListEntity.voteAverage ?: 0.0, cnt) )
            cnt++
            ratingImage9.setImageResource( starRate(moviesListEntity.voteAverage ?: 0.0, cnt) )
            cnt++
            ratingImage10.setImageResource( starRate(moviesListEntity.voteAverage ?: 0.0, cnt) )

            //Загрузка картинки
            Picasso.get()
                .load(moviesListEntity.backdropPath) // адрес url
                .fit() // уменьшения размера и настройка
                .placeholder(R.drawable.ic_launcher_foreground) // показывает картинку пока не загрузилась картинка
                .into(viewBinding.imageView) // вкладывает картинку в место назначения

            //настраивает избраное, красит сердечко
            favoritesImage.setImageResource(
                if (moviesListEntity.isFavourite) R.drawable.favorite_black
                else R.drawable.favorite_border_black
            )
        //обработка клики по сердечку(добавление/удаление избранного)
            favoritesImage.setOnClickListener{
                onItemCallback.onFavoriteClick(moviesListEntity.id)
            }
        // обработка клика по итему ресайклера, для перехода в другое активити
            root.setOnClickListener{
                onItemCallback.onItemClick(moviesListEntity.title, moviesListEntity.id)
            }
        }
    }

    //интерфейс для обработки кликов по итемам ресайлкервью

    interface ItemClickListener{
        fun onItemClick(title: String?, id: Int)

        fun onFavoriteClick(id: Int){

        }
    }
}

