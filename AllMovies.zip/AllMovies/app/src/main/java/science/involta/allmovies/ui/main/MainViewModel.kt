package science.involta.allmovies.ui.main

import androidx.lifecycle.ViewModel

class MainViewModel(): ViewModel()